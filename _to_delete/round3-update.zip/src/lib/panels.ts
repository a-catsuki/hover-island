import type { WidgetConfig } from './ipc'
import { widgetPages } from './widgetPages'

export type PanelId = string
export const DEFAULT_PANEL_ORDER: PanelId[] = ['today', 'desk', 'activity']
export const MAX_PANEL_COUNT = 128

export const SIZE_PRESETS = {
  small: { label: 'Small', collapsed: { w: 232, h: 32 }, expanded: { w: 500, h: 420 } },
  medium: { label: 'Medium', collapsed: { w: 288, h: 32 }, expanded: { w: 620, h: 440 } },
  large: { label: 'Large', collapsed: { w: 344, h: 32 }, expanded: { w: 740, h: 450 } },
} as const

export interface PanelLayout {
  panels: Record<PanelId, string>
  panelOrder: PanelId[]
  widgets: WidgetConfig[]
}

/** Capacity pages become ordinary user pages as soon as their layout is edited.
 * This keeps the legacy capacity migration from undoing a deliberate move. */
export function customizePanelLayout(layout: PanelLayout): { layout: PanelLayout; ids: Map<string, string> } {
  const ids = new Map(layout.panelOrder.filter(id => id.startsWith('overflow-')).map(id => [id, `panel-${crypto.randomUUID()}`]))
  const remap = (id: string) => ids.get(id) ?? id
  return {
    ids,
    layout: {
      panels: Object.fromEntries(Object.entries(layout.panels).map(([id, title]) => [remap(id), title])),
      panelOrder: layout.panelOrder.map(remap),
      widgets: layout.widgets.map(widget => ({ ...widget, panel: widget.panel ? remap(widget.panel) : widget.panel })),
    },
  }
}

export function reorderPanel(order: string[], source: string, target: string, after = false): string[] {
  if (source === target || !order.includes(source) || !order.includes(target)) return [...order]
  const next = order.filter(id => id !== source)
  next.splice(next.indexOf(target) + (after ? 1 : 0), 0, source)
  return next
}

const validPanelId = (id: string) => /^[a-z0-9][a-z0-9_-]{0,63}$/i.test(id)
const cleanTitle = (title: string, fallback: string) => title.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 24) || fallback

export function defaultPanelForKind(kind: string, panelOrder: PanelId[] = DEFAULT_PANEL_ORDER): PanelId {
  const preferred = ['media', 'weather', 'calendar'].includes(kind) ? 'today'
    : ['notes', 'dock', 'focus', 'clock', 'nearby'].includes(kind) ? 'desk' : 'activity'
  return panelOrder.includes(preferred) ? preferred : panelOrder[0] ?? 'today'
}

export function widgetPanel(widget: WidgetConfig, panelOrder: PanelId[] = DEFAULT_PANEL_ORDER): PanelId {
  return widget.panel && panelOrder.includes(widget.panel) ? widget.panel : defaultPanelForKind(widget.kind, panelOrder)
}

export function moveToPanel(widgets: WidgetConfig[], id: string, panel: PanelId): WidgetConfig[] {
  return widgets.map(widget => widget.id === id ? { ...widget, panel } : widget)
}

function generatedOverflowId(base: string, suffix: number, panels: Record<string, string>): string {
  const stem = `overflow-${base.slice(0, 48)}-${suffix}`
  let id = stem
  let serial = 2
  while (panels[id]) id = `${stem}-${serial++}`
  return id
}

function generatedOverflowParent(id: string, panels: Record<string, string>): string | null {
  for (const base of Object.keys(panels).filter(candidate => !candidate.startsWith('overflow-')).sort((a, b) => b.length - a.length)) {
    const prefix = `overflow-${base}-`
    if (!id.startsWith(prefix)) continue
    const suffix = id.slice(prefix.length).split('-')
    if (!suffix.length || !suffix.every(part => /^\d+$/.test(part))) continue
    if (panels[id] === `${panels[base]} ${suffix[0]}`) return base
  }
  return null
}

/** Normalize saved panels using the same two-column cell geometry as the editor. */
export function fitPanelLayout(
  sourcePanels: Record<string, string> | null | undefined,
  sourceOrder: string[] | null | undefined,
  sourceWidgets: WidgetConfig[],
): PanelLayout {
  const panels: Record<string, string> = {}
  for (const [rawId, rawTitle] of Object.entries(sourcePanels ?? {}).slice(0, MAX_PANEL_COUNT)) {
    const id = rawId.trim()
    if (validPanelId(id) && typeof rawTitle === 'string') panels[id] = cleanTitle(rawTitle, 'Panel')
  }
  if (!Object.keys(panels).length) panels.today = 'Today'

  const panelOrder: string[] = []
  for (const id of sourceOrder ?? []) {
    if (typeof id === 'string' && panels[id] && !panelOrder.includes(id)) panelOrder.push(id)
  }
  for (const id of Object.keys(panels)) if (!panelOrder.includes(id)) panelOrder.push(id)

  let widgets = sourceWidgets.map(widget => ({ ...widget }))
  // Preserve a valid panel assignment even when the old file lacks its label.
  for (const widget of widgets) {
    if (!widget.panel || !validPanelId(widget.panel) || panels[widget.panel]) continue
    if (Object.keys(panels).length >= MAX_PANEL_COUNT) {
      widget.panel = panelOrder[0]
      continue
    }
    panels[widget.panel] = `Recovered ${panelOrder.length + 1}`
    panelOrder.push(widget.panel)
  }
  widgets = widgets.map(widget => ({ ...widget, panel: widgetPanel(widget, panelOrder) }))

  // Earlier releases persisted capacity-generated overflow pages as if they
  // were user pages. Fold only untouched generated labels back into their root
  // so the current geometry can repack them. Renamed pages remain user-owned.
  for (const id of [...panelOrder]) {
    const parent = generatedOverflowParent(id, panels)
    if (!parent) continue
    widgets = widgets.map(widget => widget.panel === id ? { ...widget, panel: parent } : widget)
    delete panels[id]
    panelOrder.splice(panelOrder.indexOf(id), 1)
  }

  const roots = [...panelOrder]
  for (const root of roots) {
    const members = widgets.filter(widget => widget.panel === root).sort((a, b) => a.order - b.order)
    const pages = widgetPages(members, 2)
    let insertAt = panelOrder.indexOf(root) + 1
    for (let pageIndex = 1; pageIndex < pages.length && panelOrder.length < MAX_PANEL_COUNT; pageIndex++) {
      const suffix = pageIndex + 1
      const id = generatedOverflowId(root, suffix, panels)
      panels[id] = cleanTitle(`${panels[root]} ${suffix}`, `Panel ${suffix}`)
      panelOrder.splice(insertAt++, 0, id)
      const pageIds = new Set(pages[pageIndex].map(slot => slot.widget.id))
      widgets = widgets.map(widget => pageIds.has(widget.id) ? { ...widget, panel: id } : widget)
    }
  }

  // Overflow pages are derived from capacity. Remove them again when a resize
  // or move leaves them empty, while retaining user-created and disabled-only pages.
  for (const id of [...panelOrder]) {
    if (!id.startsWith('overflow-') || widgets.some(widget => widget.panel === id)) continue
    delete panels[id]
    panelOrder.splice(panelOrder.indexOf(id), 1)
  }
  return { panels, panelOrder, widgets }
}

export function createPanelLayout(layout: PanelLayout, title = 'New panel'): PanelLayout {
  if (layout.panelOrder.length >= MAX_PANEL_COUNT) return layout
  const panels = { ...layout.panels }
  let id = `panel-${crypto.randomUUID()}`
  while (panels[id]) id = `panel-${crypto.randomUUID()}`
  const normalized = fitPanelLayout({ ...panels, [id]: cleanTitle(title, 'New panel') }, [...layout.panelOrder, id], layout.widgets)
  return normalized
}

export function renamePanelLayout(layout: PanelLayout, id: PanelId, title: string): PanelLayout {
  if (!layout.panels[id]) return layout
  return { ...layout, panels: { ...layout.panels, [id]: cleanTitle(title, layout.panels[id]) } }
}

export function removePanelLayout(layout: PanelLayout, id: PanelId): PanelLayout {
  if (!layout.panels[id] || layout.panelOrder.length <= 1) return layout
  const panelOrder = layout.panelOrder.filter(panel => panel !== id)
  const panels = { ...layout.panels }
  delete panels[id]
  let widgets = layout.widgets.map(widget => ({ ...widget }))
  const displaced = widgets.filter(widget => widget.panel === id).sort((a, b) => a.order - b.order)
  widgets = widgets.filter(widget => widget.panel !== id)
  for (const widget of displaced) {
    const destination = [...panelOrder].sort((a, b) =>
      widgets.filter(item => item.panel === a && item.enabled && item.kind !== 'airdrop').length -
      widgets.filter(item => item.panel === b && item.enabled && item.kind !== 'airdrop').length,
    )[0]
    widgets.push({ ...widget, panel: destination })
  }
  return fitPanelLayout(panels, panelOrder, widgets)
}

/* ------------------------------------------------------------------ dedicated pages
   Quick controls and Beam are ordinary pages (tab, order, rename) that happen to be
   created for their widget. Their tab shows only while that widget is enabled there. */

export const SPECIAL_PANELS = [
  { id: 'quick-controls', kind: 'controls', title: 'Quick controls' },
  { id: 'beam', kind: 'nearby', title: 'Beam' },
] as const

export const specialPanelForKind = (kind: string) => SPECIAL_PANELS.find(spec => spec.kind === kind)

/** A dedicated page is hidden from the tab strip when its widget is not enabled in it. */
export function panelVisible(id: PanelId, widgets: readonly Pick<WidgetConfig, 'kind' | 'enabled' | 'panel'>[]): boolean {
  const spec = SPECIAL_PANELS.find(item => item.id === id)
  if (!spec) return true
  return widgets.some(widget => widget.kind === spec.kind && widget.enabled && widget.panel === id)
}

export const visiblePanelOrder = (order: readonly PanelId[], widgets: readonly Pick<WidgetConfig, 'kind' | 'enabled' | 'panel'>[]): PanelId[] =>
  order.filter(id => panelVisible(id, widgets))

/** Move (or create) a widget kind into its own page, enabling it. Pure: returns the new layout. */
export function dedicatePanelLayout(layout: PanelLayout, kind: string): PanelLayout {
  const spec = specialPanelForKind(kind)
  if (!spec) return layout
  const panels = { ...layout.panels }
  const order = [...layout.panelOrder]
  if (!panels[spec.id]) {
    if (order.length >= MAX_PANEL_COUNT) return layout
    panels[spec.id] = spec.title
    order.push(spec.id)
  }
  const widgets = layout.widgets.map(widget => widget.kind === kind ? { ...widget, enabled: true, panel: spec.id, slot: undefined } : { ...widget })
  return fitPanelLayout(panels, order, widgets)
}

/* ------------------------------------------------------------------ custom page names */

export const PANEL_NAME_MAX = 16

export function cleanPanelName(raw: string): string {
  return raw.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, PANEL_NAME_MAX).trim()
}

/** Keep only known pages with non-empty names (mirrors settings.rs validation). */
export function normalizePanelNames(names: Record<string, string> | null | undefined, panels: Record<string, string>): Record<string, string> {
  const result: Record<string, string> = {}
  for (const [id, value] of Object.entries(names ?? {})) {
    if (!Object.hasOwn(panels, id) || typeof value !== 'string') continue
    const clean = cleanPanelName(value)
    if (clean) result[id] = clean
  }
  return result
}

/** An empty name, or one equal to the default title, resets the page to its default. */
export function setPanelName(names: Record<string, string> | undefined, panels: Record<string, string>, id: PanelId, raw: string): Record<string, string> {
  const next = { ...(names ?? {}) }
  const clean = cleanPanelName(raw)
  if (!clean || clean === panels[id]) delete next[id]
  else next[id] = clean
  return normalizePanelNames(next, panels)
}

export const panelDisplayName = (id: PanelId, panels: Record<string, string>, names?: Record<string, string>): string =>
  (names && names[id]) || panels[id] || ''
