use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct NowPlaying {
    pub title: String,
    pub artist: String,
    pub album: Option<String>,
    pub thumbnail: Option<String>,
    /// "playing" | "paused" | "stopped"
    pub status: String,
    pub position: Option<f64>,
    pub duration: Option<f64>,
    /// Capabilities reported by the active Windows media session.
    pub can_play: bool,
    pub can_pause: bool,
    pub can_skip_next: bool,
    pub can_skip_previous: bool,
    pub can_seek: bool,
    /// Valid seek interval in seconds when `can_seek` is true.
    pub seek_min: Option<f64>,
    pub seek_max: Option<f64>,
    pub source_app: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct AppNotification {
    pub id: String,
    pub app: String,
    pub title: String,
    pub body: String,
    pub timestamp: u64,
    pub icon: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InstalledApp {
    pub id: String,
    pub name: String,
    /// File path for "win32"/"url" apps, the AppUserModelId for "uwp" apps.
    pub target: String,
    /// "win32" | "uwp" | "url"
    pub kind: String,
    pub icon: Option<String>,
    /// Last time Windows recorded this app being run (ms since epoch), from UserAssist.
    #[serde(default)]
    pub last_used: Option<u64>,
    /// Windows run count for this app (UserAssist); 0 when unknown.
    #[serde(default)]
    pub use_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct UsageSnapshot {
    pub provider: String,
    pub label: String,
    /// "ok" | "unknown" | "error"
    pub status: String,
    pub used: Option<u64>,
    pub limit: Option<u64>,
    pub unit: Option<String>,
    pub percent: Option<f64>,
    pub window: Option<String>,
    pub detail: Option<String>,
    /// "official-rate-limit" for provider quota data, "local-logs" for local activity.
    pub source: Option<String>,
    /// Provider supplied reset time in Unix milliseconds, when known.
    pub reset_at: Option<u64>,
    pub updated_at: u64,
    /// Local session activity for this provider, when its logs could be read.
    pub activity: Option<ActivityInfo>,
}

/// One recent agent session found in a provider's local logs.
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct RecentSession {
    pub id: String,
    pub title: String,
    pub project: Option<String>,
    pub started_at: Option<u64>,
    pub last_active_at: u64,
    pub tokens: Option<u64>,
    pub active: bool,
}

/// Session level facts derived from a provider's local logs.
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct ActivityInfo {
    pub installed: bool,
    pub sessions_24h: u32,
    pub sessions_7d: u32,
    pub last_active_at: Option<u64>,
    /// Mean time from a prompt to the first reply, over the last 24 hours.
    pub avg_response_ms: Option<u64>,
    pub responses_24h: u32,
    /// A session log was written within the last two minutes.
    pub active_now: bool,
    pub active_sessions: u32,
    pub recent: Vec<RecentSession>,
}

pub fn now_millis() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct SearchResult {
    pub id: String,
    pub title: String,
    pub subtitle: Option<String>,
    /// "app" | "file" | "url" | "calc" | "web" | "command"
    pub kind: String,
    pub icon: Option<String>,
    /// "launch" | "open" | "copy" | "run"
    pub action: String,
    pub target: String,
    pub score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct NearbyPeer {
    pub id: String,
    pub name: String,
    pub address: String,
    pub port: u16,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct NearbyTransfer {
    pub id: String,
    pub peer: String,
    /// "send" | "receive"
    pub direction: String,
    pub file_name: String,
    pub bytes: u64,
    pub total: u64,
    /// "active" | "done" | "failed"
    pub status: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct NearbyStatus {
    pub running: bool,
    pub device_name: String,
    pub port: u16,
    pub peers: Vec<NearbyPeer>,
    pub transfers: Vec<NearbyTransfer>,
    pub detail: Option<String>,
}

/// An explicit grid cell (1-based) a widget was dropped into in the editor.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WidgetSlot {
    pub row: u8,
    pub column: u8,
}

/// A dashboard widget placement. `kind` is one of the frontend `WidgetKind` strings.
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WidgetConfig {
    pub id: String,
    pub kind: String,
    pub enabled: bool,
    pub order: i32,
    pub panel: Option<String>,
    pub clock_style: Option<String>,
    pub size: Option<String>,
    pub show_lyrics: Option<bool>,
    /// The grid cell the user dropped this widget into; absent means flow order.
    pub slot: Option<WidgetSlot>,
}

/// A connected web app (WhatsApp Web, Gmail, …) surfaced in the notch.
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct AppConnection {
    pub id: String,
    pub name: String,
    pub url: String,
    /// data: URL or remote URL
    pub icon: Option<String>,
    /// Surface this app's notifications in the notch.
    pub notifications: bool,
    /// Exact Windows notification app display names that should route here.
    pub notification_sources: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WeatherSnapshot {
    pub ok: bool,
    pub city: String,
    pub temp_c: f64,
    pub hi_c: f64,
    pub lo_c: f64,
    /// WMO weather code.
    pub code: i32,
    pub label: String,
    pub updated_at: u64,
    /// Modelled U.S. air-quality index, when available.
    pub aqi: Option<u16>,
    /// Human-readable U.S. AQI band with the standard named explicitly.
    pub aqi_label: Option<String>,
    /// `manual` for a user-selected city, `approximate` for IP-derived location.
    pub location_source: Option<String>,
    /// Whether the displayed forecast was served from the local cache after a fetch failure.
    pub stale: Option<bool>,
    /// Apparent temperature in Celsius.
    pub feels_like_c: Option<f64>,
    pub humidity_pct: Option<u8>,
    pub wind_speed_kmh: Option<f64>,
    pub wind_direction_deg: Option<u16>,
    pub precipitation_mm: Option<f64>,
    pub is_day: Option<bool>,
    pub pressure_hpa: Option<f64>,
    pub cloud_cover_pct: Option<u8>,
    pub timezone: Option<String>,
    pub hourly: Vec<WeatherHour>,
    pub daily: Vec<WeatherDay>,
    /// Modelled CAMS ensemble particulate matter concentrations in μg/m³.
    #[serde(rename = "pm25")]
    pub pm2_5: Option<f64>,
    pub pm10: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WeatherHour {
    pub time: String,
    pub temperature_c: f64,
    pub code: i32,
    pub precipitation_probability: Option<u8>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WeatherDay {
    pub date: String,
    pub code: i32,
    pub high_c: f64,
    pub low_c: f64,
    pub sunrise: Option<String>,
    pub sunset: Option<String>,
    pub precipitation_probability: Option<u8>,
    pub uv_index_max: Option<f64>,
    pub wind_speed_max_kmh: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct WeatherLocation {
    pub name: String,
    pub admin1: Option<String>,
    pub country: Option<String>,
    pub latitude: f64,
    pub longitude: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct CalendarEvent {
    pub id: String,
    pub title: String,
    /// epoch millis
    pub start: u64,
    /// epoch millis
    pub end: u64,
    pub all_day: bool,
    pub location: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
#[serde(rename_all = "camelCase", default)]
pub struct NotesState {
    pub text: String,
}
